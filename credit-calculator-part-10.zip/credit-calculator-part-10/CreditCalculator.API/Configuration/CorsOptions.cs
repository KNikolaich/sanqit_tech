﻿namespace CreditCalculator.API.Configuration;

public class CorsOptions
{
    public string[] Origins { get; set; } = [];
}