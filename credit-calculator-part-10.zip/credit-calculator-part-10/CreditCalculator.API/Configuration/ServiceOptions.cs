﻿namespace CreditCalculator.API.Configuration;

public class ServiceOptions
{
    public bool DisableCalculationHistory { get; set; }
}