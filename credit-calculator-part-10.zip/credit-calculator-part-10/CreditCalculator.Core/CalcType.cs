﻿namespace CreditCalculator.Core;

public enum CalcType
{
    Annuity = 1,
    Differentiated = 2
}