type CalculationParameters = {
    credit: number;
    rate: number;
    period: number;
};

export default CalculationParameters;