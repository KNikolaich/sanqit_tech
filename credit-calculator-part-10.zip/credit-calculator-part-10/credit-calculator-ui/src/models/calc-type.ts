type CalcType = "annuity" | "differentiated";
export default CalcType;