type PaymentInfo = {
    paymentNumber: number;
    payment: number;
    mainDebtPayment: number;
    percentPayment: number;
    debt: number;
}

export default PaymentInfo;